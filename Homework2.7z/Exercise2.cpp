#include "js.hpp"

namespace GView::Type::JS::Plugins
{
    using namespace GView::View::LexicalViewer;

    struct Map
    {
        u16string_view key;
        u16string_view value;

        Map(u16string_view _key, u16string_view _value)
        {
            key = _key;
            value = _value;
        }
    };

    std::string_view ComputeConcat::GetName()
    {
        return "Concat Strings";
    }

    std::string_view ComputeConcat::GetDescription()
    {
        return "Get an concat strings.";
    }

    bool ComputeConcat::CanBeAppliedOn(const GView::View::LexicalViewer::PluginData& data)
    {
        for (auto index = data.startIndex; index < data.endIndex; index++)
        {
            if (data.tokens[index].GetTypeID(TokenType::None) == TokenType::String || 
                data.tokens[index].GetTypeID(TokenType::None) == TokenType::Word)
            {
                return true;
            }
        }

        return false;
    }

    GView::View::LexicalViewer::PluginAfterActionRequest ComputeConcat::Execute(GView::View::LexicalViewer::PluginData& data)
    {
        int32 index = (int32) data.startIndex;
        vector<Map> map;

        while (index < (int32) data.endIndex)
        {
            auto tk  = data.tokens[index].GetTypeID(TokenType::None);
            auto tk2 = data.tokens[index + 1].GetTypeID(TokenType::None);
            auto tk3 = data.tokens[index + 2].GetTypeID(TokenType::None);

            if (data.tokens[index].GetTypeID(TokenType::None) == TokenType::DataType_Var && 
                data.tokens[index + 1].GetTypeID(TokenType::None) == TokenType:: Word &&
                data.tokens[index + 2].GetTypeID(TokenType::None) == TokenType::Operator_Assignment)
            {
                auto variable = data.tokens[index + 1].GetText();
                index         = index + 3;
                auto start    = data.tokens[index].GetTokenStartOffset();
                LocalUnicodeStringBuilder<256> temp;
                temp.Clear();
                temp.AddChar('"');

                while (data.tokens[index].GetTypeID(TokenType::None) != TokenType::Semicolumn)
                {
                    if (data.tokens[index].GetTypeID(TokenType::None) == TokenType::String) {
                        auto txt   = data.tokens[index].GetText();
                        auto value = txt.substr(1, txt.length() - 2);

                        if (value.find_first_of('"') == std::u16string_view::npos)
                        {
                            temp.Add(value);
                        }
                        else
                        {
                            for (auto ch : value)
                            {
                                if (ch == '"')
                                    temp.AddChar('\\');
                                temp.AddChar(ch);
                            }
                        }

                        index++;
                    }
                    else if (data.tokens[index].GetTypeID(TokenType::None) == TokenType::Word)
                    {
                        u16string_view val;

                        for (int i = 0; i < map.size(); i++)
                        {
                            if (data.tokens[index].GetText() == map[i].key)
                            {
                                val = map[i].value;
                            }
                        }

                        temp.Add(val);
                        index++;
                    }
                    else if (data.tokens[index].GetTypeID(TokenType::None) == TokenType::Operator_Plus)
                    {
                        index++;
                    }
                }

                temp.AddChar('"');
                auto end = data.tokens[index - 1].GetTokenEndOffset();
                auto size = end.value() - start.value();
                data.editor.Replace(start.value(), size, temp.ToStringView());

                Map m   = Map(variable, temp.ToStringView().substr(1, temp.ToStringView().length() - 2));
                map.push_back(m);
            }

            index++;
        }

        return GView::View::LexicalViewer::PluginAfterActionRequest::Rescan;
    }
} 
